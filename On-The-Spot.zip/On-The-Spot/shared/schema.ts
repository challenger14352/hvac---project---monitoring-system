import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, doublePrecision, timestamp, jsonb, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const customers = pgTable("customers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  location: text("location").notNull(),
  plan: text("plan").notNull().default("premium"),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true });
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export const units = pgTable("units", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  systemType: text("system_type").default("split_ac"),
  timezone: text("timezone").default("America/New_York"),
});

export const insertUnitSchema = createInsertSchema(units).omit({ id: true });
export type InsertUnit = z.infer<typeof insertUnitSchema>;
export type Unit = typeof units.$inferSelect;

export const readings = pgTable("readings", {
  unitId: varchar("unit_id").notNull().references(() => units.id, { onDelete: "cascade" }),
  ts: timestamp("ts", { withTimezone: true }).notNull().defaultNow(),
  key: text("key").notNull(),
  value: doublePrecision("value").notNull(),
}, (table) => [
  primaryKey({ columns: [table.unitId, table.ts, table.key] }),
]);

export const insertReadingSchema = createInsertSchema(readings).omit({});
export type InsertReading = z.infer<typeof insertReadingSchema>;
export type Reading = typeof readings.$inferSelect;

export const diagnostics = pgTable("diagnostics", {
  unitId: varchar("unit_id").notNull().references(() => units.id, { onDelete: "cascade" }),
  ts: timestamp("ts", { withTimezone: true }).notNull().defaultNow(),
  metric: text("metric").notNull(),
  value: doublePrecision("value").notNull(),
  meta: jsonb("meta").default({}),
}, (table) => [
  primaryKey({ columns: [table.unitId, table.ts, table.metric] }),
]);

export type Diagnostic = typeof diagnostics.$inferSelect;

export const unitStatus = pgTable("unit_status", {
  unitId: varchar("unit_id").primaryKey().references(() => units.id, { onDelete: "cascade" }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  healthScore: doublePrecision("health_score").notNull().default(100),
  faults: jsonb("faults").notNull().default({}),
});

export type UnitStatus = typeof unitStatus.$inferSelect;

export const ingestPayloadSchema = z.object({
  unitId: z.string(),
  ts: z.string().datetime().optional(),
  readings: z.record(z.string(), z.number()),
});

export type IngestPayload = z.infer<typeof ingestPayloadSchema>;

export * from "./models/auth";
