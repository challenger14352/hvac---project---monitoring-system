import { storage } from "./storage";
import { deltaT, restrictionScore, shortCycleScore, lowChargeSuspicion, healthScore } from "./scoring";

export async function runWorker(unitId: string) {
  const now = new Date();
  const since10m = new Date(now.getTime() - 10 * 60 * 1000);
  const since1h = new Date(now.getTime() - 60 * 60 * 1000);

  const rReading = await storage.getLatestReading(unitId, "temp_return_f", since10m);
  const sReading = await storage.getLatestReading(unitId, "temp_supply_f", since10m);

  if (!rReading || !sReading) return;

  const tempReturnF = rReading.value;
  const tempSupplyF = sReading.value;
  const dt = deltaT(tempReturnF, tempSupplyF);

  const ampBlowerR = await storage.getLatestReading(unitId, "amp_blower", since10m);
  const ampCondenserR = await storage.getLatestReading(unitId, "amp_condenser", since10m);
  const dpFilterR = await storage.getLatestReading(unitId, "dp_filter_pa", since10m);

  const ampBlowerV = ampBlowerR?.value ?? null;
  const ampCondV = ampCondenserR?.value ?? null;
  const dpFilterV = dpFilterR?.value ?? null;

  const callYRows = await storage.getReadingSeries(unitId, "call_y", since1h);
  const callYSeries = callYRows.map(r => Math.round(r.value));

  let runtimeMin = 0;
  if (callYSeries.length >= 2) {
    const ones = callYSeries.filter(v => v === 1).length;
    runtimeMin = ones * 1.0;
  }

  const restr = restrictionScore(dt, ampBlowerV, dpFilterV);
  const sc = shortCycleScore(callYSeries, 60);
  const lowc = lowChargeSuspicion(dt, ampCondV, runtimeMin);
  const hs = healthScore(restr.score, sc.score, lowc.score);

  const ts = now;
  await storage.insertDiagnostics([
    { unitId, ts, metric: "delta_t_f", value: dt, meta: { temp_return_f: tempReturnF, temp_supply_f: tempSupplyF } },
    { unitId, ts, metric: "restriction_score", value: restr.score, meta: restr.meta },
    { unitId, ts, metric: "short_cycle_score", value: sc.score, meta: sc.meta },
    { unitId, ts, metric: "low_charge_suspicion", value: lowc.score, meta: lowc.meta },
    { unitId, ts, metric: "health_score", value: hs, meta: {} },
  ]);

  const faults = {
    restriction: { score: restr.score, meta: restr.meta },
    short_cycling: { score: sc.score, meta: sc.meta },
    low_charge: { score: lowc.score, meta: lowc.meta },
  };

  await storage.upsertUnitStatus(unitId, hs, faults);
}
