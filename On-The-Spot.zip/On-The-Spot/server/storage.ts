import { eq, desc, gte, asc, sql, and } from "drizzle-orm";
import { db } from "./db";
import {
  customers, units, readings, diagnostics, unitStatus,
  type Customer, type InsertCustomer,
  type Unit, type InsertUnit,
  type Reading, type UnitStatus, type Diagnostic,
} from "@shared/schema";

export interface IStorage {
  getCustomers(): Promise<(Customer & { unitCount: number; healthScore: number | null })[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  createCustomer(c: InsertCustomer): Promise<Customer>;
  deleteCustomer(id: string): Promise<void>;

  getUnits(customerId: string): Promise<Unit[]>;
  getUnit(id: string): Promise<Unit | undefined>;
  createUnit(u: InsertUnit): Promise<Unit>;

  insertReadings(unitId: string, ts: Date, data: Record<string, number>): Promise<void>;

  getLatestReading(unitId: string, key: string, since: Date): Promise<Reading | undefined>;
  getReadingSeries(unitId: string, key: string, since: Date): Promise<Reading[]>;
  getLatestReadingsForUnit(unitId: string): Promise<Reading[]>;

  upsertUnitStatus(unitId: string, healthScore: number, faults: Record<string, any>): Promise<void>;
  getUnitStatus(unitId: string): Promise<UnitStatus | undefined>;

  insertDiagnostics(rows: { unitId: string; ts: Date; metric: string; value: number; meta: any }[]): Promise<void>;
  getRecentDiagnostics(unitId: string, limit?: number): Promise<Diagnostic[]>;

  getFleetStats(): Promise<{ totalUnits: number; optimal: number; critical: number; avgHealth: number }>;
}

export class DatabaseStorage implements IStorage {
  async getCustomers() {
    const result = await db.execute(sql`
      SELECT c.*, 
        COALESCE((SELECT COUNT(*) FROM units u WHERE u.customer_id = c.id), 0) as unit_count,
        (SELECT AVG(us.health_score) FROM unit_status us JOIN units u ON us.unit_id = u.id WHERE u.customer_id = c.id) as health_score
      FROM customers c
      ORDER BY c.name ASC
    `);
    return result.rows.map((r: any) => ({
      id: r.id,
      name: r.name,
      location: r.location,
      plan: r.plan,
      unitCount: Number(r.unit_count),
      healthScore: r.health_score ? Number(r.health_score) : null,
    }));
  }

  async getCustomer(id: string) {
    const [row] = await db.select().from(customers).where(eq(customers.id, id));
    return row;
  }

  async createCustomer(c: InsertCustomer) {
    const [row] = await db.insert(customers).values(c).returning();
    return row;
  }

  async deleteCustomer(id: string) {
    await db.delete(customers).where(eq(customers.id, id));
  }

  async getUnits(customerId: string) {
    return db.select().from(units).where(eq(units.customerId, customerId));
  }

  async getUnit(id: string) {
    const [row] = await db.select().from(units).where(eq(units.id, id));
    return row;
  }

  async createUnit(u: InsertUnit) {
    const [row] = await db.insert(units).values(u).returning();
    return row;
  }

  async insertReadings(unitId: string, ts: Date, data: Record<string, number>) {
    const rows = Object.entries(data).map(([key, value]) => ({
      unitId,
      ts,
      key,
      value,
    }));
    if (rows.length === 0) return;
    
    for (const row of rows) {
      await db.execute(sql`
        INSERT INTO readings (unit_id, ts, key, value) 
        VALUES (${row.unitId}, ${row.ts}, ${row.key}, ${row.value})
        ON CONFLICT (unit_id, ts, key) DO UPDATE SET value = EXCLUDED.value
      `);
    }
  }

  async getLatestReading(unitId: string, key: string, since: Date) {
    const [row] = await db.select().from(readings)
      .where(and(eq(readings.unitId, unitId), eq(readings.key, key), gte(readings.ts, since)))
      .orderBy(desc(readings.ts))
      .limit(1);
    return row;
  }

  async getReadingSeries(unitId: string, key: string, since: Date) {
    return db.select().from(readings)
      .where(and(eq(readings.unitId, unitId), eq(readings.key, key), gte(readings.ts, since)))
      .orderBy(asc(readings.ts));
  }

  async getLatestReadingsForUnit(unitId: string) {
    const result = await db.execute(sql`
      SELECT DISTINCT ON (key) * FROM readings 
      WHERE unit_id = ${unitId}
      ORDER BY key, ts DESC
    `);
    return result.rows as unknown as Reading[];
  }

  async upsertUnitStatus(unitId: string, healthScore: number, faults: Record<string, any>) {
    await db.execute(sql`
      INSERT INTO unit_status (unit_id, updated_at, health_score, faults)
      VALUES (${unitId}, NOW(), ${healthScore}, ${JSON.stringify(faults)}::jsonb)
      ON CONFLICT (unit_id) DO UPDATE SET 
        updated_at = NOW(),
        health_score = EXCLUDED.health_score,
        faults = EXCLUDED.faults
    `);
  }

  async getUnitStatus(unitId: string) {
    const [row] = await db.select().from(unitStatus).where(eq(unitStatus.unitId, unitId));
    return row;
  }

  async insertDiagnostics(rows: { unitId: string; ts: Date; metric: string; value: number; meta: any }[]) {
    if (rows.length === 0) return;
    for (const row of rows) {
      await db.execute(sql`
        INSERT INTO diagnostics (unit_id, ts, metric, value, meta)
        VALUES (${row.unitId}, ${row.ts}, ${row.metric}, ${row.value}, ${JSON.stringify(row.meta)}::jsonb)
        ON CONFLICT (unit_id, ts, metric) DO UPDATE SET value = EXCLUDED.value, meta = EXCLUDED.meta
      `);
    }
  }

  async getRecentDiagnostics(unitId: string, limit = 80) {
    return db.select().from(diagnostics)
      .where(eq(diagnostics.unitId, unitId))
      .orderBy(desc(diagnostics.ts))
      .limit(limit);
  }

  async getFleetStats() {
    const result = await db.execute(sql`
      SELECT 
        (SELECT COUNT(*) FROM units) as total_units,
        (SELECT COUNT(*) FROM unit_status WHERE health_score >= 85) as optimal,
        (SELECT COUNT(*) FROM unit_status WHERE health_score < 60) as critical,
        (SELECT COALESCE(AVG(health_score), 0) FROM unit_status) as avg_health
    `);
    const r = result.rows[0] as any;
    return {
      totalUnits: Number(r.total_units),
      optimal: Number(r.optimal),
      critical: Number(r.critical),
      avgHealth: Number(r.avg_health),
    };
  }
}

export const storage = new DatabaseStorage();
