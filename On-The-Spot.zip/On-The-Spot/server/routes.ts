import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCustomerSchema, insertUnitSchema, ingestPayloadSchema } from "@shared/schema";
import { runWorker } from "./worker";
import { isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // --- Customers ---
  app.get("/api/customers", isAuthenticated, async (_req, res) => {
    const customers = await storage.getCustomers();
    res.json(customers);
  });

  app.get("/api/customers/:id", isAuthenticated, async (req, res) => {
    const customer = await storage.getCustomer(req.params.id);
    if (!customer) return res.status(404).json({ message: "Customer not found" });
    res.json(customer);
  });

  app.post("/api/customers", isAuthenticated, async (req, res) => {
    const parsed = insertCustomerSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
    const customer = await storage.createCustomer(parsed.data);
    res.status(201).json(customer);
  });

  app.delete("/api/customers/:id", isAuthenticated, async (req, res) => {
    await storage.deleteCustomer(req.params.id);
    res.json({ ok: true });
  });

  // --- Units ---
  app.get("/api/customers/:customerId/units", isAuthenticated, async (req, res) => {
    const units = await storage.getUnits(req.params.customerId);
    res.json(units);
  });

  app.post("/api/customers/:customerId/units", isAuthenticated, async (req, res) => {
    const parsed = insertUnitSchema.safeParse({ ...req.body, customerId: req.params.customerId });
    if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
    const unit = await storage.createUnit(parsed.data);
    res.status(201).json(unit);
  });

  // --- Unit Detail (readings, status, diagnostics) ---
  app.get("/api/units/:id", isAuthenticated, async (req, res) => {
    const unit = await storage.getUnit(req.params.id);
    if (!unit) return res.status(404).json({ message: "Unit not found" });
    const status = await storage.getUnitStatus(req.params.id);
    const latestReadings = await storage.getLatestReadingsForUnit(req.params.id);
    const recentDiag = await storage.getRecentDiagnostics(req.params.id, 50);
    res.json({ unit, status, latestReadings, diagnostics: recentDiag });
  });

  // --- Ingest ---
  app.post("/api/ingest", isAuthenticated, async (req, res) => {
    const parsed = ingestPayloadSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten() });

    const { unitId, ts, readings: readingsData } = parsed.data;

    const unit = await storage.getUnit(unitId);
    if (!unit) return res.status(404).json({ message: "Unit not found" });

    const timestamp = ts ? new Date(ts) : new Date();
    await storage.insertReadings(unitId, timestamp, readingsData);

    await runWorker(unitId);

    res.json({ ok: true, unitId, ts: timestamp.toISOString(), count: Object.keys(readingsData).length });
  });

  // --- Fleet Stats ---
  app.get("/api/fleet/stats", isAuthenticated, async (_req, res) => {
    const stats = await storage.getFleetStats();
    res.json(stats);
  });

  return httpServer;
}
