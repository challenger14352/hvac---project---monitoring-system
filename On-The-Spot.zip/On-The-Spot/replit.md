# On The Spot — Remote HVAC Diagnostic Platform

## Overview
A multi-tenant SaaS platform that provides remote HVAC diagnostic capabilities. Translates physical sensor signals (temperature, pressure, electrical, mechanical) into physics-derived diagnostics with automated health scoring and fault detection.

## Current State
- Full-stack Express + React application running on port 5000
- PostgreSQL database with Drizzle ORM
- Real-time diagnostics engine computing health scores on each sensor ingest
- Seed data: 5 customers, 10 units with varying health profiles
- Brand: "On The Spot" with eagle logo, golden/amber theme

## Authentication
- Replit Auth (OpenID Connect) with email/password, Google, GitHub, Apple login
- Password reset handled via Replit's auth provider
- All API routes protected with isAuthenticated middleware
- Landing page shown for unauthenticated users; dashboard for authenticated users
- User profile and logout shown in sidebar

## Architecture
```
client/src/pages/LandingPage.tsx       → Public landing page for logged-out users
client/src/pages/CompanyDashboard.tsx  → Customer list ("/")
client/src/pages/CustomerDetail.tsx    → Units list per customer ("/customer/:id")
client/src/pages/UnitDashboard.tsx     → Unit diagnostic detail ("/unit/:id")
shared/schema.ts                      → Data models (customers, units, readings, diagnostics, unit_status, users, sessions)
shared/models/auth.ts                 → Auth schema (users, sessions tables)
server/replit_integrations/auth/      → Auth module (OIDC setup, session, routes)
server/storage.ts                     → Database access layer (DatabaseStorage)
server/routes.ts                      → API routes (/api/customers, /api/units, /api/ingest, /api/fleet/stats)
server/scoring.ts                     → Physics-based scoring functions (restriction, short cycling, low charge, health)
server/worker.ts                      → Diagnostic worker triggered on each ingest
server/db.ts                          → PostgreSQL pool/connection
```

## API Endpoints
- `GET /api/customers` — list with unit counts and avg health
- `POST /api/customers` — create { name, location, plan }
- `DELETE /api/customers/:id`
- `GET /api/customers/:customerId/units`
- `POST /api/customers/:customerId/units` — create { name, systemType }
- `GET /api/units/:id` — detail with status, readings, diagnostics
- `POST /api/ingest` — { unitId, ts?, readings: Record<string,number> }
- `GET /api/fleet/stats` — { totalUnits, optimal, critical, avgHealth }

## Design
- Dark theme with golden/amber primary (hsl 40, 95-100%, 55%)
- Eagle logo from attached_assets/AOF_eagle_1771799559884.png
- Fonts: JetBrains Mono for data, Inter for UI
- Three tabs on unit dashboard: MVP Core, God Mode, Unit Health

## Service Tiers
- Basic (MVP Core): temperature + basic health scoring
- Premium (God Mode): full diagnostic suite
- Enterprise: predictive AI (future)

## Key Scoring Metrics
- Health Score: weighted composite (0-100)
- Restriction Score: airflow restriction from deltaT, blower amps, filter dP
- Short Cycle Score: compressor starts per hour
- Low Charge Suspicion: long runtime + low deltaT pattern

## Recent Changes
- 2026-02-22: Built full backend (schema, storage, routes, scoring, worker)
- 2026-02-22: Wired frontend to real API data (customers, units, fleet stats)
- 2026-02-22: Added CustomerDetail page for unit navigation flow
- 2026-02-22: Seeded demo data (5 customers, 10 units, sensor readings)
- 2026-02-22: Rebranded from NEXUS.HVAC to "On The Spot" with eagle logo and golden/amber theme
- 2026-02-22: Added user management with Replit Auth (login, password, email reset), protected all API routes, landing page for logged-out users
